package com.example.belajarchapter

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.os.bundleOf
import androidx.navigation.Navigation
import kotlinx.android.synthetic.main.fragment_four.*
import kotlinx.android.synthetic.main.fragment_second.*

class FourFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_four, container, false)
    }
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        backtotiga.setOnClickListener{
            val nama = arguments?.getString("nama")
            val usia = tv_usia.text.toString().toInt()
            val alamat = tv_alamat.text.toString()
            val pekerjaan = tv_pekerjaan.text.toString()
            val keterangan =if (usia % 2 == 0){
                "Genap"
            }else{
                "Ganjil"
            }


            val data = bundleOf("usia" to usia, "alamat" to alamat, "pekerjaan" to pekerjaan, "keterangan" to keterangan)
            Navigation.findNavController(view).navigate(R.id.navigasiback_fragmenttiga, data)

        }
    }
}



